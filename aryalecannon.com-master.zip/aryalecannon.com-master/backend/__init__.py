# This will be where the initialization of the flask app will occur

import os
from flask import Flask, render_template

# application factory
def create_app():
    app = Flask(__name__)
    app.config.from_mapping(
        SECRET_KEY = "replace with random val"

    )
    from .views import nav_bar
    app.register_blueprint(nav_bar.bp)

    return app