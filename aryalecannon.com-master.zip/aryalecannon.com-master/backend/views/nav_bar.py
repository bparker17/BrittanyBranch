from flask import (
    Blueprint, flash, redirect, render_template, request, session, url_for, jsonify
)

bp = Blueprint('navbar', __name__)

@bp.route('/')
@bp.route('/home')
def home():
    return render_template('index.html', token="HOMEEEEEEE")

@bp.route('/contact')
def contact():
    return render_template('index.html', token="CONTACTTTTTTT")
