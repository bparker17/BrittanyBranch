import React from 'react';
import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <p>{window.token}</p>
        <p>whats the deal</p>
       
      </header>
    </div>
  );
}

export default App;
